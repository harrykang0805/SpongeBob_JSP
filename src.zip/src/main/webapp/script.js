// 폼 유효성 검사 함수
function validateForm() {
    // 아이디 유효성 검사
    var idInput = document.getElementById("아이디").querySelector("input"); // 아이디 입력 필드
    if (idInput.value.length < 4) {
        alert("아이디는 네 글자 이상이어야 합니다.");
        return false; // 유효성 검사 실패
    }

    // 우편번호 유효성 검사
    var postalCodeInput = document.getElementById("우편번호").querySelector("input"); // 우편번호 입력 필드
    if (!postalCodeInput.value.length==5) {
        alert("우편번호는 다섯자리 입니다");
        return false; // 유효성 검사 실패
    }

    // 비밀번호 일치 검사
    var passwordInput = document.getElementById("비밀번호").querySelector("input"); // 비밀번호 입력 필드
    var confirmPasswordInput = document.getElementById("비밀번호확인").querySelector("input"); // 비밀번호 확인 입력 필드
    if (passwordInput.value !== confirmPasswordInput.value) {
        alert("비밀번호와 비밀번호 확인이 일치하지 않습니다.");
        return false; // 유효성 검사 실패
    }

    return true; // 유효성 검사 통과
}

document.querySelector(".우편번호찾기버튼").addEventListener("click", function (event) { // 주소 확인 버튼 클릭 이벤트
    event.preventDefault();
    new daum.Postcode({ // 다음 우편번호 서비스 사용
        oncomplete: function (data) {
            let addr;
            if (data.userSelectedType === "R") {
                addr = data.roadAddress; // 도로명 주소
            } else {
                addr = data.jibunAddress; // 지번 주소
            }
            document.querySelector(".주소인풋").value = addr; // 주소 필드에 주소 입력
            document.querySelector(".우편번호인풋").value = data.zonecode; // 우편번호 필드에 우편번호 입력
        },
    }).open(); // 다음 우편번호 서비스 오픈
});

function chageLangSelect(){
    var langSelect = document.getElementById("이메일도메인");

    // select element에서 선택된 option의 value가 저장된다.
    var selectValue = langSelect.options[langSelect.selectedIndex].value;

    // select element에서 선택된 option의 text가 저장된다.
    var selectText = langSelect.options[langSelect.selectedIndex].text;

    // 해당 input 필드의 값을 선택된 도메인 값으로 설정한다.
    document.querySelector('input[name="emailDomain"]').value = selectText;

    return selectText;
}
